
INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3906.0', '0', '3907.0', 'STABSd9ff8272952a8fa3', '2022-04-30', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/05/Tpop4_d2204.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2656.0', '1.0', '2657.0', 'STABS94c19cfe1fe2b1d9', '2022-04-30', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/05/Tpop4_d2204.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('1752.0', '0', '1752.0', 'STABS455d0dbb7996946a', '2022-04-30', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/05/Tpop4_d2204.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3118.0', '0', '3118.0', 'STABS3d65edca83e57c7c', '2022-04-30', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/05/Tpop4_d2204.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('135.0', '2018.0', '2204.0', 'STABS4efb195360574a90', '2022-04-30', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/05/Tpop4_d2204.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2902.0', '0', '2903.0', 'STABSe667924f40413b79', '2022-04-30', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/05/Tpop4_d2204.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2148.0', '27.0', '2182.0', 'STABS728a3ccf3fb61ce8', '2022-04-30', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/05/Tpop4_d2204.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2632.0', '35.0', '2672.0', 'STABS8eb67d8b2b4bed7b', '2022-04-30', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/05/Tpop4_d2204.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('49.0', '931.0', '1002.0', 'STABS53455af8a017eb5e', '2022-04-30', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/05/Tpop4_d2204.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3283.0', '25.0', '3314.0', 'STABS498a5c1357c12346', '2022-04-30', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/05/Tpop4_d2204.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('1907.0', '39.0', '1950.0', 'STABS1ede7b0dea5394bf', '2022-04-30', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/05/Tpop4_d2204.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3413.0', '4.0', '3419.0', 'STABS6c5e068ca71a45f9', '2022-04-30', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/05/Tpop4_d2204.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2308.0', '0', '2308.0', 'STABSc7983f5361f8c383', '2022-04-30', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/05/Tpop4_d2204.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3980.0', '2.0', '3983.0', 'STABSc0a0b7e2d198245e', '2022-04-30', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/05/Tpop4_d2204.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2347.0', '0', '2348.0', 'STABS09ff452de3c773d0', '2022-04-30', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/05/Tpop4_d2204.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2731.0', '0', '2731.0', 'STABSd3fecfa368e8b994', '2022-04-30', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/05/Tpop4_d2204.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2359.0', '2.0', '2363.0', 'STABSd3c5ca96cf1bddf4', '2022-04-30', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/05/Tpop4_d2204.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('1992.0', '0', '1992.0', 'STABS07704a4dbeef476c', '2022-04-30', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/05/Tpop4_d2204.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3152.0', '34.0', '3195.0', 'STABS5dd06da28c51d7f6', '2022-04-30', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/05/Tpop4_d2204.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2630.0', '2.0', '2640.0', 'STABS30a60e6ab45f122f', '2022-04-30', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/05/Tpop4_d2204.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3666.0', '124.0', '3842.0', 'STABS7398fde2ae957291', '2022-04-30', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/05/Tpop4_d2204.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('4071.0', '3.0', '4075.0', 'STABS4d5311cdbd15c492', '2022-04-30', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/05/Tpop4_d2204.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('1817.0', '0', '1817.0', 'STABS899ffc3c31eac665', '2022-04-30', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/05/Tpop4_d2204.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2560.0', '0', '2560.0', 'STABSd07c9b03d4f8d698', '2022-04-30', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/05/Tpop4_d2204.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3202.0', '107.0', '3340.0', 'STABS5e6ff2a276c20175', '2022-04-30', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/05/Tpop4_d2204.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('1867.0', '39.0', '1915.0', 'STABS70e4ffbd7dba64b2', '2022-04-30', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/05/Tpop4_d2204.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('4312.0', '99.0', '4443.0', 'STABSec1defeb360bc6be', '2022-04-30', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/05/Tpop4_d2204.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2658.0', '0', '2659.0', 'STABS2532b4b99f5a02a1', '2022-04-30', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/05/Tpop4_d2204.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3243.0', '0', '3243.0', 'STABS58618ca84f467991', '2022-04-30', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/05/Tpop4_d2204.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3125.0', '20.0', '3158.0', 'STABSd020357496289dca', '2022-04-30', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/05/Tpop4_d2204.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2782.0', '61.0', '2862.0', 'STABS9dfa014ae084708e', '2022-04-30', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/05/Tpop4_d2204.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2946.0', '1.0', '2947.0', 'STABSedf4b9aae8f25692', '2022-04-30', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/05/Tpop4_d2204.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3669.0', '8.0', '3677.0', 'STABSea76f6dea58c56be', '2022-04-30', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/05/Tpop4_d2204.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3840.0', '0', '3840.0', 'STABSd9ff8272952a8fa3', '2021-12-31', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/01/Tpop4_d2112.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2883.0', '0', '2883.0', 'STABS94c19cfe1fe2b1d9', '2021-12-31', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/01/Tpop4_d2112.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('1663.0', '0', '1663.0', 'STABS455d0dbb7996946a', '2021-12-31', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/01/Tpop4_d2112.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3073.0', '0', '3073.0', 'STABS3d65edca83e57c7c', '2021-12-31', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/01/Tpop4_d2112.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('86.0', '2142.0', '2278.0', 'STABS4efb195360574a90', '2021-12-31', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/01/Tpop4_d2112.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2832.0', '0', '2832.0', 'STABSe667924f40413b79', '2021-12-31', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/01/Tpop4_d2112.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2193.0', '24.0', '2221.0', 'STABS728a3ccf3fb61ce8', '2021-12-31', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/01/Tpop4_d2112.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2677.0', '36.0', '2718.0', 'STABS8eb67d8b2b4bed7b', '2021-12-31', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/01/Tpop4_d2112.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('55.0', '961.0', '1034.0', 'STABS53455af8a017eb5e', '2021-12-31', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/01/Tpop4_d2112.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3219.0', '19.0', '3244.0', 'STABS498a5c1357c12346', '2021-12-31', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/01/Tpop4_d2112.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('1985.0', '41.0', '2033.0', 'STABS1ede7b0dea5394bf', '2021-12-31', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/01/Tpop4_d2112.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3614.0', '1.0', '3615.0', 'STABS6c5e068ca71a45f9', '2021-12-31', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/01/Tpop4_d2112.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2689.0', '0', '2690.0', 'STABSc7983f5361f8c383', '2021-12-31', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/01/Tpop4_d2112.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('4240.0', '1.0', '4242.0', 'STABSc0a0b7e2d198245e', '2021-12-31', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/01/Tpop4_d2112.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2507.0', '1.0', '2509.0', 'STABS09ff452de3c773d0', '2021-12-31', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/01/Tpop4_d2112.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2702.0', '0', '2702.0', 'STABSd3fecfa368e8b994', '2021-12-31', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/01/Tpop4_d2112.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2301.0', '14.0', '2317.0', 'STABSd3c5ca96cf1bddf4', '2021-12-31', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/01/Tpop4_d2112.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2246.0', '0', '2246.0', 'STABS07704a4dbeef476c', '2021-12-31', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/01/Tpop4_d2112.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3323.0', '34.0', '3363.0', 'STABS5dd06da28c51d7f6', '2021-12-31', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/01/Tpop4_d2112.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2761.0', '4.0', '2771.0', 'STABS30a60e6ab45f122f', '2021-12-31', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/01/Tpop4_d2112.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3669.0', '110.0', '3823.0', 'STABS7398fde2ae957291', '2021-12-31', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/01/Tpop4_d2112.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3741.0', '2.0', '3743.0', 'STABS4d5311cdbd15c492', '2021-12-31', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/01/Tpop4_d2112.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('1985.0', '0', '1985.0', 'STABS899ffc3c31eac665', '2021-12-31', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/01/Tpop4_d2112.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2602.0', '0', '2602.0', 'STABSd07c9b03d4f8d698', '2021-12-31', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/01/Tpop4_d2112.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3251.0', '94.0', '3371.0', 'STABS5e6ff2a276c20175', '2021-12-31', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/01/Tpop4_d2112.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('1872.0', '28.0', '1908.0', 'STABS70e4ffbd7dba64b2', '2021-12-31', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/01/Tpop4_d2112.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('4837.0', '86.0', '4958.0', 'STABSec1defeb360bc6be', '2021-12-31', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/01/Tpop4_d2112.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3183.0', '0', '3184.0', 'STABS2532b4b99f5a02a1', '2021-12-31', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/01/Tpop4_d2112.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3313.0', '0', '3313.0', 'STABS58618ca84f467991', '2021-12-31', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/01/Tpop4_d2112.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3107.0', '22.0', '3142.0', 'STABSd020357496289dca', '2021-12-31', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/01/Tpop4_d2112.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2937.0', '59.0', '3003.0', 'STABS9dfa014ae084708e', '2021-12-31', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/01/Tpop4_d2112.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2962.0', '1.0', '2963.0', 'STABSedf4b9aae8f25692', '2021-12-31', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/01/Tpop4_d2112.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3973.0', '6.0', '3979.0', 'STABSea76f6dea58c56be', '2021-12-31', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/01/Tpop4_d2112.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3741.0', '0', '3742.0', 'STABSd9ff8272952a8fa3', '2022-02-28', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/03/Tpop4_d2202.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2719.0', '0', '2719.0', 'STABS94c19cfe1fe2b1d9', '2022-02-28', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/03/Tpop4_d2202.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('1630.0', '0', '1630.0', 'STABS455d0dbb7996946a', '2022-02-28', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/03/Tpop4_d2202.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3123.0', '1.0', '3126.0', 'STABS3d65edca83e57c7c', '2022-02-28', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/03/Tpop4_d2202.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('91.0', '1976.0', '2120.0', 'STABS4efb195360574a90', '2022-02-28', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/03/Tpop4_d2202.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2863.0', '0', '2863.0', 'STABSe667924f40413b79', '2022-02-28', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/03/Tpop4_d2202.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2109.0', '26.0', '2140.0', 'STABS728a3ccf3fb61ce8', '2022-02-28', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/03/Tpop4_d2202.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2484.0', '34.0', '2523.0', 'STABS8eb67d8b2b4bed7b', '2022-02-28', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/03/Tpop4_d2202.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('52.0', '934.0', '1006.0', 'STABS53455af8a017eb5e', '2022-02-28', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/03/Tpop4_d2202.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3174.0', '19.0', '3198.0', 'STABS498a5c1357c12346', '2022-02-28', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/03/Tpop4_d2202.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('1869.0', '41.0', '1918.0', 'STABS1ede7b0dea5394bf', '2022-02-28', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/03/Tpop4_d2202.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3439.0', '4.0', '3444.0', 'STABS6c5e068ca71a45f9', '2022-02-28', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/03/Tpop4_d2202.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2384.0', '0', '2384.0', 'STABSc7983f5361f8c383', '2022-02-28', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/03/Tpop4_d2202.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('4079.0', '1.0', '4081.0', 'STABSc0a0b7e2d198245e', '2022-02-28', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/03/Tpop4_d2202.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2401.0', '0', '2402.0', 'STABS09ff452de3c773d0', '2022-02-28', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/03/Tpop4_d2202.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2682.0', '0', '2682.0', 'STABSd3fecfa368e8b994', '2022-02-28', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/03/Tpop4_d2202.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2215.0', '8.0', '2225.0', 'STABSd3c5ca96cf1bddf4', '2022-02-28', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/03/Tpop4_d2202.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2077.0', '0', '2077.0', 'STABS07704a4dbeef476c', '2022-02-28', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/03/Tpop4_d2202.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3291.0', '30.0', '3328.0', 'STABS5dd06da28c51d7f6', '2022-02-28', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/03/Tpop4_d2202.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2728.0', '4.0', '2739.0', 'STABS30a60e6ab45f122f', '2022-02-28', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/03/Tpop4_d2202.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3584.0', '122.0', '3760.0', 'STABS7398fde2ae957291', '2022-02-28', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/03/Tpop4_d2202.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3515.0', '0', '3515.0', 'STABS4d5311cdbd15c492', '2022-02-28', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/03/Tpop4_d2202.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('1916.0', '0', '1916.0', 'STABS899ffc3c31eac665', '2022-02-28', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/03/Tpop4_d2202.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2519.0', '0', '2519.0', 'STABSd07c9b03d4f8d698', '2022-02-28', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/03/Tpop4_d2202.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3194.0', '109.0', '3331.0', 'STABS5e6ff2a276c20175', '2022-02-28', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/03/Tpop4_d2202.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('1745.0', '33.0', '1786.0', 'STABS70e4ffbd7dba64b2', '2022-02-28', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/03/Tpop4_d2202.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('4655.0', '101.0', '4791.0', 'STABSec1defeb360bc6be', '2022-02-28', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/03/Tpop4_d2202.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2948.0', '1.0', '2950.0', 'STABS2532b4b99f5a02a1', '2022-02-28', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/03/Tpop4_d2202.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3192.0', '0', '3192.0', 'STABS58618ca84f467991', '2022-02-28', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/03/Tpop4_d2202.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3013.0', '20.0', '3046.0', 'STABSd020357496289dca', '2022-02-28', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/03/Tpop4_d2202.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2888.0', '59.0', '2958.0', 'STABS9dfa014ae084708e', '2022-02-28', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/03/Tpop4_d2202.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2907.0', '1.0', '2908.0', 'STABSedf4b9aae8f25692', '2022-02-28', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/03/Tpop4_d2202.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3178.0', '3.0', '3181.0', 'STABSea76f6dea58c56be', '2022-02-28', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/03/Tpop4_d2202.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3731.0', '0', '3731.0', 'STABSd9ff8272952a8fa3', '2022-01-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/02/Tpop4_d2201.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2799.0', '0', '2799.0', 'STABS94c19cfe1fe2b1d9', '2022-01-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/02/Tpop4_d2201.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('1495.0', '0', '1495.0', 'STABS455d0dbb7996946a', '2022-01-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/02/Tpop4_d2201.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3042.0', '0', '3043.0', 'STABS3d65edca83e57c7c', '2022-01-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/02/Tpop4_d2201.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('90.0', '2072.0', '2214.0', 'STABS4efb195360574a90', '2022-01-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/02/Tpop4_d2201.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2746.0', '0', '2746.0', 'STABSe667924f40413b79', '2022-01-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/02/Tpop4_d2201.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2151.0', '27.0', '2182.0', 'STABS728a3ccf3fb61ce8', '2022-01-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/02/Tpop4_d2201.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2513.0', '37.0', '2554.0', 'STABS8eb67d8b2b4bed7b', '2022-01-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/02/Tpop4_d2201.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('54.0', '922.0', '995.0', 'STABS53455af8a017eb5e', '2022-01-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/02/Tpop4_d2201.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3189.0', '20.0', '3215.0', 'STABS498a5c1357c12346', '2022-01-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/02/Tpop4_d2201.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('1928.0', '40.0', '1976.0', 'STABS1ede7b0dea5394bf', '2022-01-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/02/Tpop4_d2201.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3494.0', '3.0', '3498.0', 'STABS6c5e068ca71a45f9', '2022-01-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/02/Tpop4_d2201.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2517.0', '0', '2517.0', 'STABSc7983f5361f8c383', '2022-01-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/02/Tpop4_d2201.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('4164.0', '1.0', '4166.0', 'STABSc0a0b7e2d198245e', '2022-01-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/02/Tpop4_d2201.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2454.0', '0', '2455.0', 'STABS09ff452de3c773d0', '2022-01-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/02/Tpop4_d2201.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2665.0', '0', '2665.0', 'STABSd3fecfa368e8b994', '2022-01-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/02/Tpop4_d2201.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2222.0', '9.0', '2233.0', 'STABSd3c5ca96cf1bddf4', '2022-01-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/02/Tpop4_d2201.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2147.0', '0', '2147.0', 'STABS07704a4dbeef476c', '2022-01-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/02/Tpop4_d2201.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3267.0', '32.0', '3306.0', 'STABS5dd06da28c51d7f6', '2022-01-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/02/Tpop4_d2201.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2743.0', '4.0', '2753.0', 'STABS30a60e6ab45f122f', '2022-01-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/02/Tpop4_d2201.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3597.0', '117.0', '3767.0', 'STABS7398fde2ae957291', '2022-01-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/02/Tpop4_d2201.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3793.0', '1.0', '3794.0', 'STABS4d5311cdbd15c492', '2022-01-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/02/Tpop4_d2201.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('1932.0', '0', '1932.0', 'STABS899ffc3c31eac665', '2022-01-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/02/Tpop4_d2201.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2525.0', '0', '2525.0', 'STABSd07c9b03d4f8d698', '2022-01-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/02/Tpop4_d2201.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3221.0', '103.0', '3353.0', 'STABS5e6ff2a276c20175', '2022-01-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/02/Tpop4_d2201.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('1784.0', '33.0', '1825.0', 'STABS70e4ffbd7dba64b2', '2022-01-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/02/Tpop4_d2201.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('4735.0', '90.0', '4859.0', 'STABSec1defeb360bc6be', '2022-01-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/02/Tpop4_d2201.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3012.0', '1.0', '3014.0', 'STABS2532b4b99f5a02a1', '2022-01-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/02/Tpop4_d2201.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3248.0', '0', '3248.0', 'STABS58618ca84f467991', '2022-01-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/02/Tpop4_d2201.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3032.0', '21.0', '3066.0', 'STABSd020357496289dca', '2022-01-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/02/Tpop4_d2201.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2897.0', '61.0', '2969.0', 'STABS9dfa014ae084708e', '2022-01-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/02/Tpop4_d2201.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2901.0', '1.0', '2902.0', 'STABSedf4b9aae8f25692', '2022-01-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/02/Tpop4_d2201.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3621.0', '6.0', '3627.0', 'STABSea76f6dea58c56be', '2022-01-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/02/Tpop4_d2201.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3830.0', '0', '3831.0', 'STABSd9ff8272952a8fa3', '2022-03-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/04/Tpop4_d2203.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2737.0', '0', '2737.0', 'STABS94c19cfe1fe2b1d9', '2022-03-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/04/Tpop4_d2203.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('1649.0', '0', '1649.0', 'STABS455d0dbb7996946a', '2022-03-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/04/Tpop4_d2203.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3119.0', '1.0', '3121.0', 'STABS3d65edca83e57c7c', '2022-03-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/04/Tpop4_d2203.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('119.0', '2065.0', '2241.0', 'STABS4efb195360574a90', '2022-03-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/04/Tpop4_d2203.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2952.0', '0', '2952.0', 'STABSe667924f40413b79', '2022-03-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/04/Tpop4_d2203.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2152.0', '30.0', '2189.0', 'STABS728a3ccf3fb61ce8', '2022-03-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/04/Tpop4_d2203.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2501.0', '37.0', '2544.0', 'STABS8eb67d8b2b4bed7b', '2022-03-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/04/Tpop4_d2203.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('53.0', '917.0', '990.0', 'STABS53455af8a017eb5e', '2022-03-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/04/Tpop4_d2203.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3170.0', '22.0', '3197.0', 'STABS498a5c1357c12346', '2022-03-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/04/Tpop4_d2203.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('1863.0', '40.0', '1910.0', 'STABS1ede7b0dea5394bf', '2022-03-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/04/Tpop4_d2203.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3418.0', '5.0', '3424.0', 'STABS6c5e068ca71a45f9', '2022-03-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/04/Tpop4_d2203.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2297.0', '0', '2297.0', 'STABSc7983f5361f8c383', '2022-03-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/04/Tpop4_d2203.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('4037.0', '1.0', '4039.0', 'STABSc0a0b7e2d198245e', '2022-03-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/04/Tpop4_d2203.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2399.0', '0', '2400.0', 'STABS09ff452de3c773d0', '2022-03-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/04/Tpop4_d2203.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2743.0', '0', '2743.0', 'STABSd3fecfa368e8b994', '2022-03-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/04/Tpop4_d2203.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2246.0', '5.0', '2253.0', 'STABSd3c5ca96cf1bddf4', '2022-03-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/04/Tpop4_d2203.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2062.0', '0', '2062.0', 'STABS07704a4dbeef476c', '2022-03-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/04/Tpop4_d2203.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3213.0', '30.0', '3252.0', 'STABS5dd06da28c51d7f6', '2022-03-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/04/Tpop4_d2203.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2734.0', '3.0', '2743.0', 'STABS30a60e6ab45f122f', '2022-03-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/04/Tpop4_d2203.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3633.0', '121.0', '3805.0', 'STABS7398fde2ae957291', '2022-03-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/04/Tpop4_d2203.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3719.0', '0', '3719.0', 'STABS4d5311cdbd15c492', '2022-03-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/04/Tpop4_d2203.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('1852.0', '0', '1852.0', 'STABS899ffc3c31eac665', '2022-03-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/04/Tpop4_d2203.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2635.0', '0', '2635.0', 'STABSd07c9b03d4f8d698', '2022-03-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/04/Tpop4_d2203.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3236.0', '103.0', '3370.0', 'STABS5e6ff2a276c20175', '2022-03-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/04/Tpop4_d2203.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('1700.0', '34.0', '1743.0', 'STABS70e4ffbd7dba64b2', '2022-03-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/04/Tpop4_d2203.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('4597.0', '100.0', '4731.0', 'STABSec1defeb360bc6be', '2022-03-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/04/Tpop4_d2203.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2902.0', '0', '2903.0', 'STABS2532b4b99f5a02a1', '2022-03-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/04/Tpop4_d2203.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3212.0', '0', '3212.0', 'STABS58618ca84f467991', '2022-03-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/04/Tpop4_d2203.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3008.0', '19.0', '3040.0', 'STABSd020357496289dca', '2022-03-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/04/Tpop4_d2203.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2784.0', '62.0', '2859.0', 'STABS9dfa014ae084708e', '2022-03-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/04/Tpop4_d2203.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2940.0', '1.0', '2941.0', 'STABSedf4b9aae8f25692', '2022-03-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/04/Tpop4_d2203.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3274.0', '6.0', '3280.0', 'STABSea76f6dea58c56be', '2022-03-31', 'https://www.cdcr.ca.gov/research/2022-monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2022/04/Tpop4_d2203.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3759.0', '0', '3759.0', 'STABSd9ff8272952a8fa3', '2021-11-30', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2021/12/Tpop4_d2111.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2918.0', '0', '2918.0', 'STABS94c19cfe1fe2b1d9', '2021-11-30', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2021/12/Tpop4_d2111.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('1735.0', '0', '1735.0', 'STABS455d0dbb7996946a', '2021-11-30', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2021/12/Tpop4_d2111.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2677.0', '0', '2677.0', 'STABS3d65edca83e57c7c', '2021-11-30', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2021/12/Tpop4_d2111.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('88.0', '2089.0', '2227.0', 'STABS4efb195360574a90', '2021-11-30', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2021/12/Tpop4_d2111.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2851.0', '0', '2851.0', 'STABSe667924f40413b79', '2021-11-30', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2021/12/Tpop4_d2111.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2178.0', '23.0', '2205.0', 'STABS728a3ccf3fb61ce8', '2021-11-30', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2021/12/Tpop4_d2111.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2644.0', '39.0', '2688.0', 'STABS8eb67d8b2b4bed7b', '2021-11-30', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2021/12/Tpop4_d2111.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('53.0', '966.0', '1034.0', 'STABS53455af8a017eb5e', '2021-11-30', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2021/12/Tpop4_d2111.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3149.0', '15.0', '3170.0', 'STABS498a5c1357c12346', '2021-11-30', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2021/12/Tpop4_d2111.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('1946.0', '38.0', '1990.0', 'STABS1ede7b0dea5394bf', '2021-11-30', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2021/12/Tpop4_d2111.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3622.0', '3.0', '3625.0', 'STABS6c5e068ca71a45f9', '2021-11-30', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2021/12/Tpop4_d2111.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2768.0', '0', '2769.0', 'STABSc7983f5361f8c383', '2021-11-30', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2021/12/Tpop4_d2111.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('4305.0', '1.0', '4308.0', 'STABSc0a0b7e2d198245e', '2021-11-30', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2021/12/Tpop4_d2111.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2492.0', '1.0', '2494.0', 'STABS09ff452de3c773d0', '2021-11-30', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2021/12/Tpop4_d2111.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2637.0', '0', '2637.0', 'STABSd3fecfa368e8b994', '2021-11-30', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2021/12/Tpop4_d2111.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2938.0', '6.0', '2949.0', 'STABSd3c5ca96cf1bddf4', '2021-11-30', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2021/12/Tpop4_d2111.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2227.0', '0', '2227.0', 'STABS07704a4dbeef476c', '2021-11-30', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2021/12/Tpop4_d2111.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3350.0', '30.0', '3385.0', 'STABS5dd06da28c51d7f6', '2021-11-30', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2021/12/Tpop4_d2111.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2723.0', '4.0', '2732.0', 'STABS30a60e6ab45f122f', '2021-11-30', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2021/12/Tpop4_d2111.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3601.0', '115.0', '3762.0', 'STABS7398fde2ae957291', '2021-11-30', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2021/12/Tpop4_d2111.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3636.0', '0', '3636.0', 'STABS4d5311cdbd15c492', '2021-11-30', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2021/12/Tpop4_d2111.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2024.0', '0', '2024.0', 'STABS899ffc3c31eac665', '2021-11-30', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2021/12/Tpop4_d2111.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2626.0', '0', '2626.0', 'STABSd07c9b03d4f8d698', '2021-11-30', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2021/12/Tpop4_d2111.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3216.0', '89.0', '3328.0', 'STABS5e6ff2a276c20175', '2021-11-30', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2021/12/Tpop4_d2111.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('1950.0', '35.0', '1991.0', 'STABS70e4ffbd7dba64b2', '2021-11-30', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2021/12/Tpop4_d2111.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('4891.0', '84.0', '5005.0', 'STABSec1defeb360bc6be', '2021-11-30', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2021/12/Tpop4_d2111.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3230.0', '0', '3231.0', 'STABS2532b4b99f5a02a1', '2021-11-30', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2021/12/Tpop4_d2111.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3310.0', '0', '3310.0', 'STABS58618ca84f467991', '2021-11-30', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2021/12/Tpop4_d2111.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3017.0', '23.0', '3055.0', 'STABSd020357496289dca', '2021-11-30', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2021/12/Tpop4_d2111.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2926.0', '49.0', '2982.0', 'STABS9dfa014ae084708e', '2021-11-30', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2021/12/Tpop4_d2111.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('2985.0', '2.0', '2987.0', 'STABSedf4b9aae8f25692', '2021-11-30', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2021/12/Tpop4_d2111.pdf');

INSERT INTO inmate_population_snapshots(male,female,total,id,snapshot_date,source_url,source_url_2) VALUES ('3788.0', '4.0', '3792.0', 'STABSea76f6dea58c56be', '2021-11-30', 'https://www.cdcr.ca.gov/research/monthly-total-population-report-tpop4-archive/', 'https://www.cdcr.ca.gov/research/wp-content/uploads/sites/174/2021/12/Tpop4_d2111.pdf');
