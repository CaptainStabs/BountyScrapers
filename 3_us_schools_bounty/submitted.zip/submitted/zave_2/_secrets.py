notify_url = "https://notify.run/c/6qSUDJ6E7P07QDIg"
binary_path = "C:\\Users\\adria\\AppData\\Local\\Google\\Chrome\\Application\\chrome.exe"
driver_path = "C:\\Users\\adria\\github\\BountyScrapers\\3_us_schools_bounty\\zave_1\\chromedriver.exe"
